package app.main.start;

import javax.swing.JFrame;

import app.main.Panel;

class Frame extends JFrame {
   Frame(String title) {
      super(title);

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setResizable(false);
      add(new Panel());

      pack();
      setLocationRelativeTo(null);
      setVisible(true);
   }
}