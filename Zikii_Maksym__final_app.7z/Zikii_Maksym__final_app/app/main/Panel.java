package app.main;

import javax.swing.*;
import java.awt.*;

import app.entities.Player;
import app.tiles.TileManager;
import app.objects.Object;

public class Panel extends JPanel implements Runnable {
   final int preTileSize = 16; // 16px
   public final int scale = 3;
   public final int postTileSize = preTileSize * scale; // 48px

   public final int maxScreenRow = 9;
   public final int maxScreenCol = 16;

   public final int windowWidth = postTileSize * maxScreenCol; // 768px
   public final int windowHeight = postTileSize * maxScreenRow; // 432px

   Background background = new Background(this);
   public int backgroundX = (int) (-2.5 * postTileSize);
   public int backgroundY = -2 * postTileSize + 18;

   public final int maxWorldRow = 50;
   public final int maxWorldCol = 52;
   public final int worldWidth = maxWorldCol * postTileSize;
   public final int worldHeight = maxWorldRow * postTileSize;

   TileManager tileManager = new TileManager(this);
   public UI ui = new UI(this);

   public final int FPS = 60;

   Thread time;
   KeyEvents keyHandler = new KeyEvents();

   public CollisionChecker checker = new CollisionChecker(this);
   public AssetSetter assetSetter = new AssetSetter(this);

   public Player player = new Player(this, keyHandler);

   public Object object[] = new Object[10];

   public Panel() {
      setPreferredSize(new Dimension(windowWidth, windowHeight));
      setBackground(Color.white);
      setDoubleBuffered(true); // for better rendering perfomance

      setupGame();
      timeStart();

      this.addKeyListener(keyHandler);

      this.setFocusable(true); // for from-launch key listening
   }

   public void setupGame() {
      assetSetter.setObjects();
   }

   private void timeStart() {
      time = new Thread(this);
      time.start();
   }

   public void run() {
      double displayInterval = 1000000000 / FPS; // 0.01(6)
      double displayTimes = 0;
      long lastDisplayTime = System.nanoTime();
      long currentTime;

      long delta;

      long stopwatch = 0;
      int drawedTimes = 0;

      while (time != null) {
         currentTime = System.nanoTime();

         delta = currentTime - lastDisplayTime;
         displayTimes = displayTimes + delta / displayInterval;

         stopwatch = stopwatch + delta;

         lastDisplayTime = currentTime;

         if (displayTimes >= 1) {
            update();
            repaint();
            displayTimes--;
            drawedTimes++;
         }

         if (stopwatch >= 1000000000) {
            System.out.print("FPS was: " + drawedTimes + "\n");
            drawedTimes = 0;
            stopwatch = 0;
         }
      }
   }

   public void update() {
      player.update();
   }

   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      Graphics2D g2D = (Graphics2D) g;

      background.draw(g2D);
      tileManager.draw(g2D);
      for (int i = 0; i < object.length; i++) {
         if (object[i] != null) {
            object[i].draw(g2D, this);
         }
      }
      player.draw(g2D);
      ui.draw(g2D);

      g2D.dispose(); // for better rendering perfomance too
   }
}