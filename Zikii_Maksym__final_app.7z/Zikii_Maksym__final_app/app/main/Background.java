package app.main;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Background {
   BufferedImage image, backgroundImage;
   Panel panel;

   public Background(Panel panel) {
      this.panel = panel;
      loadBackground();
   }

   public void loadBackground() {
      try {
         backgroundImage = ImageIO.read(getClass().getResourceAsStream("/app/res/background.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public void draw(Graphics2D g2D) {
      image = null;
      image = backgroundImage;

      g2D.drawImage(image, panel.backgroundX, panel.backgroundY, panel.worldWidth,
            panel.windowHeight,
            null);
   }
}
