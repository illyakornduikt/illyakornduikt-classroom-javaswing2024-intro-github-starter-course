package app.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;

import app.objects.Corn;

public class UI {
   Panel panel;
   Font font, fontBold;
   BufferedImage image;

   public String message = "";
   public boolean isMessageVisible = false;

   int messageCounter = 0;
   double roundPlayTime;
   DecimalFormat decimalFormat = new DecimalFormat("#0.000");

   public boolean gameFinished = false;

   public UI(Panel panel) {
      this.panel = panel;

      font = new Font("Times New Roman", Font.PLAIN, 36);
      fontBold = new Font("Times New Roman", Font.BOLD, panel.postTileSize);

      Corn key = new Corn();
      image = key.image;
   }

   public void showMessage(String textOfMessage) {
      message = textOfMessage;
      isMessageVisible = true;
   }

   public void draw(Graphics2D g2D) {
      if (gameFinished) {
         String text;
         int textLenght;
         int x, y;

         // 1-st line
         g2D.setFont(font);
         g2D.setColor(Color.black);

         text = "You eated a lot, now you finally can feel happy :)";
         textLenght = (int) g2D.getFontMetrics().getStringBounds(text, g2D).getWidth();

         x = (panel.windowWidth / 2) - (textLenght / 2);
         y = panel.windowHeight / 2 - (int) (panel.postTileSize * 2.133);
         g2D.drawString(text, x, y);

         // 2-nd line
         g2D.setFont(fontBold);
         g2D.setColor(Color.yellow);

         text = "Congratulations!";
         textLenght = (int) g2D.getFontMetrics().getStringBounds(text, g2D).getWidth();

         x = (panel.windowWidth / 2) - (textLenght / 2);
         y = panel.windowHeight / 2 + (int) (panel.postTileSize * 0.233);
         g2D.drawString(text, x, y);

         panel.time = null; // in-game time stop

         // 3-rd line
         g2D.setFont(font);
         g2D.setColor(Color.white);

         text = "Your time is: " + decimalFormat.format(roundPlayTime);
         textLenght = (int) g2D.getFontMetrics().getStringBounds(text, g2D).getWidth();

         x = (panel.windowWidth / 2) - (textLenght / 2);
         y = panel.windowHeight / 2 + (int) (panel.postTileSize * 3.133);
         g2D.drawString(text, x, y);
      } else {
         g2D.setFont(font);
         g2D.setColor(Color.black);
         g2D.drawImage(image, panel.postTileSize / 2, panel.postTileSize / 2, panel.postTileSize, panel.postTileSize,
               null);
         g2D.drawString("x " + panel.player.hasCorn + " / 3", 78, 60);

         // in-game timer
         roundPlayTime += (double) 1 / panel.FPS;
         g2D.drawString("Time: " + decimalFormat.format(roundPlayTime), (int) (panel.postTileSize * 11.333), 60);

         // messages
         if (isMessageVisible) {
            g2D.setFont(g2D.getFont().deriveFont(18f));
            g2D.drawString(message, panel.postTileSize / 2, panel.postTileSize * 3);

            messageCounter++;

            if (messageCounter >= panel.FPS * 4) {
               messageCounter = 0;
               isMessageVisible = false;
            }
         }
      }
   }
}
