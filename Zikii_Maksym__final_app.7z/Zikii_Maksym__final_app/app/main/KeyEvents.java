package app.main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyEvents implements KeyListener {
   public boolean moveRightPressed, moveLeftPressed, jumpPressed;
   public boolean moveTopRight, moveTopLeft;

   @Override
   public void keyTyped(KeyEvent e) {
      // nothing for now..
   }

   @Override
   public void keyPressed(KeyEvent e) {
      int key = e.getKeyCode();

      if ((key == KeyEvent.VK_A && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_LEFT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_KP_LEFT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_A && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_LEFT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_KP_LEFT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_A && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_LEFT && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_KP_LEFT && key == KeyEvent.VK_KP_UP)) {
         moveTopLeft = true;
      }
      if ((key == KeyEvent.VK_D && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_RIGHT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_KP_RIGHT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_D && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_RIGHT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_KP_RIGHT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_D && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_RIGHT && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_KP_RIGHT && key == KeyEvent.VK_KP_UP)) {
         moveTopRight = true;
      }
      if (key == KeyEvent.VK_A || key == KeyEvent.VK_LEFT || key == KeyEvent.VK_KP_LEFT) {
         moveLeftPressed = true;
      }
      if (key == KeyEvent.VK_D || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_KP_RIGHT) {
         moveRightPressed = true;
      }
      if (key == KeyEvent.VK_SPACE || key == KeyEvent.VK_UP || key == KeyEvent.VK_KP_UP) {
         jumpPressed = true;
      }
   }

   @Override
   public void keyReleased(KeyEvent e) {
      int key = e.getKeyCode();

      if ((key == KeyEvent.VK_A && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_LEFT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_KP_LEFT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_A && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_LEFT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_KP_LEFT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_A && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_LEFT && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_KP_LEFT && key == KeyEvent.VK_KP_UP)) {
         moveTopLeft = false;
      }
      if ((key == KeyEvent.VK_D && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_RIGHT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_KP_RIGHT && key == KeyEvent.VK_SPACE)
            || (key == KeyEvent.VK_D && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_RIGHT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_KP_RIGHT && key == KeyEvent.VK_UP)
            || (key == KeyEvent.VK_D && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_RIGHT && key == KeyEvent.VK_KP_UP)
            || (key == KeyEvent.VK_KP_RIGHT && key == KeyEvent.VK_KP_UP)) {
         moveTopRight = false;
      }
      if (key == KeyEvent.VK_A || key == KeyEvent.VK_LEFT || key == KeyEvent.VK_KP_LEFT) {
         moveLeftPressed = false;
      }
      if (key == KeyEvent.VK_D || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_KP_RIGHT) {
         moveRightPressed = false;
      }
      if (key == KeyEvent.VK_SPACE || key == KeyEvent.VK_UP || key == KeyEvent.VK_KP_UP) {
         jumpPressed = false;
      }
   }

}
