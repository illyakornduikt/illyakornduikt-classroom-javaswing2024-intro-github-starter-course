package app.main;

import app.objects.Corn;
import app.objects.End;

public class AssetSetter {
   Panel panel;

   public AssetSetter(Panel panel) {
      this.panel = panel;
   }

   public void setObjects() {
      panel.object[0] = new Corn();
      panel.object[0].worldX = panel.postTileSize * 14;
      panel.object[0].worldY = panel.postTileSize * 2;

      panel.object[1] = new Corn();
      panel.object[1].worldX = panel.postTileSize * 22;
      panel.object[1].worldY = panel.postTileSize * 2;

      panel.object[2] = new Corn();
      panel.object[2].worldX = panel.postTileSize * 37;
      panel.object[2].worldY = panel.postTileSize * 3;

      panel.object[3] = new Corn();
      panel.object[3].worldX = panel.postTileSize * 2;
      panel.object[3].worldY = panel.postTileSize * 4;

      panel.object[4] = new End();
      panel.object[4].worldX = panel.postTileSize * 44;
      panel.object[4].worldY = panel.postTileSize * 2;

      panel.object[5] = new End();
      panel.object[5].worldX = panel.postTileSize * 44;
      panel.object[5].worldY = panel.postTileSize * 3;

      panel.object[6] = new End();
      panel.object[6].worldX = panel.postTileSize * 44;
      panel.object[6].worldY = panel.postTileSize * 4;

      panel.object[7] = new End();
      panel.object[7].worldX = panel.postTileSize * 44;
      panel.object[7].worldY = panel.postTileSize * 5;
   }
}