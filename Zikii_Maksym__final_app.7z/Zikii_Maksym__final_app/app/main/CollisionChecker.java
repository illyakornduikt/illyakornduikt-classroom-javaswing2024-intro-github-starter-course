package app.main;

import app.entities.Entity;

public class CollisionChecker {
   Panel panel;

   public CollisionChecker(Panel panel) {
      this.panel = panel;
   }

   public void checkTile(Entity entity) {
      int entityTop = entity.worldY + entity.solidPart.y;
      int entityRight = entity.worldX + entity.solidPart.x + entity.solidPart.width;
      int entityBottom = entity.worldY + entity.solidPart.y + entity.solidPart.height;
      int entityLeft = entity.worldX + entity.solidPart.x;

      int entityTopRow = entityTop / panel.postTileSize;
      int entityRightCol = entityRight / panel.postTileSize;
      int entityBottomRow = entityBottom / panel.postTileSize;
      int entityLeftCol = entityLeft / panel.postTileSize;

      int tileNum1, tileNum2;

      switch (entity.direction) {
         case "left":
            entityLeftCol = (entityLeft - entity.movementSpeed) / panel.postTileSize;
            tileNum1 = panel.tileManager.tileMap[entityLeftCol][entityTopRow];
            tileNum2 = panel.tileManager.tileMap[entityLeftCol][entityBottomRow];
            if (panel.tileManager.tile[tileNum1].collision == true ||
                  panel.tileManager.tile[tileNum2].collision == true) {
               entity.isCollided = true;
            }
            break;
         case "right":
            entityRightCol = (entityRight + entity.movementSpeed) / panel.postTileSize;
            tileNum1 = panel.tileManager.tileMap[entityRightCol][entityTopRow];
            tileNum2 = panel.tileManager.tileMap[entityRightCol][entityBottomRow];
            if (panel.tileManager.tile[tileNum1].collision == true ||
                  panel.tileManager.tile[tileNum2].collision == true) {
               entity.isCollided = true;
            }
            break;
         case "jump":
            entityTopRow = (entityTop - entity.movementSpeed) / panel.postTileSize;
            tileNum1 = panel.tileManager.tileMap[entityLeftCol][entityTopRow];
            tileNum2 = panel.tileManager.tileMap[entityRightCol][entityTopRow];
            if (panel.tileManager.tile[tileNum1].collision == true ||
                  panel.tileManager.tile[tileNum2].collision == true) {
               entity.isCollided = true;
            }
            break;
      }
      if (entity.isFalling == true) {
         entityBottomRow = (entityBottom + entity.movementSpeed) / panel.postTileSize;
         tileNum1 = panel.tileManager.tileMap[entityLeftCol][entityBottomRow];
         tileNum2 = panel.tileManager.tileMap[entityRightCol][entityBottomRow];
         if (panel.tileManager.tile[tileNum1].collision == true ||
               panel.tileManager.tile[tileNum2].collision == true) {
            entity.isFalling = false;
         }
      }
   }

   public int checkObject(Entity entity, boolean player) {
      int index = 999;

      for (int i = 0; i < panel.object.length; i++) {
         if (panel.object[i] != null) {
            // entity's solid
            entity.solidPart.x = entity.worldX + entity.solidPart.x;
            entity.solidPart.y = entity.worldY + entity.solidPart.y;
            // object's solid
            panel.object[i].solidPart.x = panel.object[i].worldX + panel.object[i].solidPart.x;
            panel.object[i].solidPart.y = panel.object[i].worldY + panel.object[i].solidPart.y;

            switch (entity.direction) {
               case "left":
                  entity.solidPart.x -= entity.movementSpeed;
                  if (entity.solidPart.intersects(panel.object[i].solidPart)) {
                     if (panel.object[i].collision == true) {
                        entity.isCollided = true;
                     }
                     if (player == true) {
                        index = i;
                     }
                  }
                  break;
               case "right":
                  entity.solidPart.x += entity.movementSpeed;
                  if (entity.solidPart.intersects(panel.object[i].solidPart)) {
                     entity.solidPart.x -= entity.movementSpeed;
                     if (entity.solidPart.intersects(panel.object[i].solidPart)) {
                        if (panel.object[i].collision == true) {
                           entity.isCollided = true;
                        }
                        if (player == true) {
                           index = i;
                        }
                     }
                  }
                  break;
            }

            entity.solidPart.x = entity.solidPartDefaultX;
            entity.solidPart.y = entity.solidPartDefaultY;
            panel.object[i].solidPart.x = panel.object[i].solidPartDefaultX;
            panel.object[i].solidPart.y = panel.object[i].solidPartDefaultY;
         }
      }
      return index;
   }
}