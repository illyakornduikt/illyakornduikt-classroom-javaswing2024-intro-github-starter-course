package app.entities;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

import app.main.Panel;
import app.main.KeyEvents;

public class Player extends Entity {
   Panel panel;
   KeyEvents keyHandler;

   // screen coordinates
   public final int screenX;
   public final int screenY;

   public int hasCorn = 0;

   public Player(Panel panel, KeyEvents keyHandler) {
      this.panel = panel;
      this.keyHandler = keyHandler;

      screenX = panel.windowWidth / 2 - (panel.postTileSize / 2);
      screenY = panel.windowHeight / 2 - (panel.postTileSize / 2) + panel.postTileSize;

      solidPart = new Rectangle();
      solidPart.x = 2 * panel.scale;
      solidPart.y = 6 * panel.scale;
      solidPart.width = 14 * panel.scale;
      solidPart.height = 9 * panel.scale;
      solidPartDefaultX = solidPart.x;
      solidPartDefaultY = solidPart.y;

      setDefaultValues();
      getPlayerImage();
   }

   public void setDefaultValues() {
      worldX = panel.postTileSize * 10;
      worldY = panel.postTileSize * 5;
      movementSpeed = 4; // may be a stick

      position = "stand";
      direction = "right";
   }

   public void getPlayerImage() {
      try {
         // right
         standR = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/right/stand.png"));
         rightStandR = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/right/rightStop.png"));
         leftStandR = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/right/leftStop.png"));
         rightProcessR = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/right/rightProcess.png"));
         leftProcessR = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/right/leftProcess.png"));
         // left
         standL = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/left/stand.png"));
         rightStandL = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/left/rightStop.png"));
         leftStandL = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/left/leftStop.png"));
         rightProcessL = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/left/rightProcess.png"));
         leftProcessL = ImageIO.read(getClass().getResourceAsStream("/app/res/chick/left/leftProcess.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public void update() {
      isFalling = true;
      isCollided = false;
      panel.checker.checkTile(this);

      int objIndexX = panel.checker.checkObject(this, true);
      pickUpObject(objIndexX);

      if (keyHandler.moveLeftPressed == true) {
         direction = "left";
         move(direction);
      }
      if (keyHandler.moveRightPressed == true) {
         direction = "right";
         move(direction);
      }
      if (keyHandler.moveLeftPressed == false && direction == "left") {
         position = "standL";
      }
      if (keyHandler.moveRightPressed == false && direction == "right") {
         position = "standR";
      }
      if (keyHandler.jumpPressed == true) {
         direction = "jump";
         move(direction);
      }
      if (isFalling == true) {
         worldY += 3;
         panel.backgroundY = panel.backgroundY - 3;
      }
   }

   public void draw(Graphics2D g2D) {
      BufferedImage image = null;

      switch (position) {
         case "standL":
            image = standL;
            break;
         case "rightProcessL":
            image = rightProcessL;
            break;
         case "rightStandL":
            image = rightStandL;
            break;
         case "leftProcessL":
            image = leftProcessL;
            break;
         case "leftStandL":
            image = leftStandL;
            break;
         case "standR":
            image = standR;
            break;
         case "rightProcessR":
            image = rightProcessR;
            break;
         case "rightStandR":
            image = rightStandR;
            break;
         case "leftProcessR":
            image = leftProcessR;
            break;
         case "leftStandR":
            image = leftStandR;
            break;
         default:
            image = standR;
            break;
      }

      g2D.drawImage(image, screenX, screenY, panel.postTileSize, panel.postTileSize, null);
   }

   public void pickUpObject(int index) {
      if (index != 999) {
         String name = panel.object[index].name;

         switch (name) {
            case "Corn":
               hasCorn++;
               panel.object[index] = null;
               if (hasCorn != 3) {
                  panel.ui.showMessage("You've collected a corn! " + "" + (3 - hasCorn) + " left..");
               }
               if (hasCorn == 3) {
                  panel.ui.showMessage("You've collected a corn! " + "" + (3 - hasCorn)
                        + " left. Go home and harry, while it's still fresh!");
               }
               break;
            case "End":
               if (hasCorn == 3) {
                  panel.ui.gameFinished = true;
                  System.out.println(
                        "You've collected all corns, you completed the game!\nThanks for playing the alpha version of game!\n");
               }
               if (hasCorn < 3) {
                  panel.ui.showMessage("To complete the game, you need to collect 3 corns! " +
                        "Go on, you still can move :)");
               }
               break;
         }
      }
   }

   public void move(String direction) {
      if (isCollided == false) {
         switch (direction) {
            case "left":
               worldX = worldX - movementSpeed; // movement of the Player
               panel.backgroundX = panel.backgroundX + movementSpeed; // background movement for the Player
               animation(direction);
               break;
            case "right":
               worldX = worldX + movementSpeed; // movement of the Player
               panel.backgroundX = panel.backgroundX - movementSpeed; // background movement for the Player
               animation(direction);
               break;
            case "jump":
               if (isFalling == false) {
                  worldY = worldY - 90;
                  panel.backgroundY = panel.backgroundY + 90;
               }
               break;
         }
      }
   }

   public void animation(String direction) {
      if (direction == "left") {
         if (spriteAnimationCounter < 14) {
            position = "rightProcessL";
         } else if (spriteAnimationCounter < 29) {
            position = "rightStandL";
         } else if (spriteAnimationCounter < 44) {
            position = "leftProcessL";
         } else if (spriteAnimationCounter < 59) {
            position = "leftStandL";
         } else if (spriteAnimationCounter == 60) {
            spriteAnimationCounter = 0;
         }
      }
      if (direction == "right") {
         if (spriteAnimationCounter < 14) {
            position = "rightProcessR";
         } else if (spriteAnimationCounter < 29) {
            position = "rightStandR";
         } else if (spriteAnimationCounter < 44) {
            position = "leftProcessR";
         } else if (spriteAnimationCounter < 59) {
            position = "leftStandR";
         } else if (spriteAnimationCounter == 60) {
            spriteAnimationCounter = 0;
         }
      }
      spriteAnimationCounter++;
   }
}