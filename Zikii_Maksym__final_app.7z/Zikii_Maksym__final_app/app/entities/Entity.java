package app.entities;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Entity {
   public int worldX, worldY;
   public int movementSpeed;

   public BufferedImage standR, rightStandR, leftStandR, rightProcessR, leftProcessR;
   public BufferedImage jumpR, fallingR;
   public BufferedImage standL, rightStandL, leftStandL, rightProcessL, leftProcessL;
   public BufferedImage jumpL, fallingL;

   public String position, direction;

   public int spriteAnimationCounter = 0;

   public Rectangle solidPart;
   public int solidPartDefaultX, solidPartDefaultY;
   public boolean isCollided = false;

   public boolean isFalling = true;
}