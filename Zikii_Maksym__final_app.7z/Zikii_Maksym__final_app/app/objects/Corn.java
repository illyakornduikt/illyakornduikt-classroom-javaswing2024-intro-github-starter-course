package app.objects;

import javax.imageio.ImageIO;
import java.io.IOException;

public class Corn extends Object {
   public Corn() {
      name = "Corn";
      try {
         image = ImageIO.read(getClass().getResourceAsStream("/app/res/objects/corn.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
}
