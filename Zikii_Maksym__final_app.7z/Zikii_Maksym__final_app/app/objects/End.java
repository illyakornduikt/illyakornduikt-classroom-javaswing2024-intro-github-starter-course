package app.objects;

import javax.imageio.ImageIO;
import java.io.IOException;

public class End extends Object {
   public End() {
      name = "End";
      try {
         image = ImageIO.read(getClass().getResourceAsStream("/app/res/objects/air.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
}
