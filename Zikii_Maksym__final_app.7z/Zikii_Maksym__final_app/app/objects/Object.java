package app.objects;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import app.main.Panel;

public class Object {
   public BufferedImage image;
   public String name;
   public boolean collision = false;
   public int worldX, worldY;

   public Rectangle solidPart = new Rectangle(0, 0, 48, 48);
   public int solidPartDefaultX = 0;
   public int solidPartDefaultY = 0;

   public void draw(Graphics2D g2D, Panel panel) {
      int screenX = worldX - panel.player.worldX + panel.player.screenX;
      int screenY = worldY - panel.player.worldY + panel.player.screenY;

      if (worldX + panel.postTileSize > panel.player.worldX - panel.player.screenX &&
            worldX - panel.postTileSize < panel.player.worldX + panel.player.screenX &&
            worldY + panel.postTileSize > panel.player.worldY - panel.player.screenY &&
            worldY - panel.postTileSize < panel.player.worldY + panel.player.screenY) {
         g2D.drawImage(image, screenX, screenY, panel.postTileSize, panel.postTileSize, null);
      }
   }
}
