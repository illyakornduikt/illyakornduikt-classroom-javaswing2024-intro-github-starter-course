package app.tiles;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;

import app.main.Panel;

public class TileManager {
   Panel panel;
   public Tile[] tile;

   public int tileMap[][];

   public TileManager(Panel panel) {
      this.panel = panel;

      tile = new Tile[10];
      tileMap = new int[panel.maxWorldCol][panel.maxWorldRow];

      getTileImage();
      loadMap("/app/maps/worldmap.txt"); // here map goes
   }

   public void getTileImage() {
      try {
         tile[0] = new Tile();
         tile[0].image = ImageIO.read(getClass().getResourceAsStream("/app/res/tiles/air.png"));
         // not collisible

         tile[1] = new Tile();
         tile[1].image = ImageIO.read(getClass().getResourceAsStream("/app/res/tiles/earth.png"));
         tile[1].collision = true;

         tile[2] = new Tile();
         tile[2].image = ImageIO.read(getClass().getResourceAsStream("/app/res/tiles/grass.png"));
         tile[2].collision = true;

         tile[3] = new Tile();
         tile[3].image = ImageIO.read(getClass().getResourceAsStream("/app/res/tiles/hay.png"));
         tile[3].collision = true;

         tile[4] = new Tile();
         tile[4].image = ImageIO.read(getClass().getResourceAsStream("/app/res/tiles/air.png"));
         tile[4].collision = true;
      } catch (IOException e) {

      }
   }

   public void loadMap(String path) {
      try {
         InputStream data = getClass().getResourceAsStream(path);
         BufferedReader reader = new BufferedReader(new InputStreamReader(data));

         int col = 0, row = 0;

         while (col < panel.maxWorldCol && row < panel.maxWorldRow) {
            String line = reader.readLine();

            while (col < panel.maxWorldCol) {
               String numbersString[] = line.split(" ");
               int numbers = Integer.parseInt(numbersString[col]);
               tileMap[col][row] = numbers;

               col++;
            }

            if (col == panel.maxWorldCol) {
               col = 0;
               row++;
            }
         }
         reader.close();
      } catch (Exception e) {
         //
      }
   }

   public void draw(Graphics2D g2D) {
      int worldCol = 0, worldRow = 0;

      while (worldCol < panel.maxWorldCol && worldRow < panel.maxWorldRow) {
         int currentTile = tileMap[worldCol][worldRow];

         int worldX = worldCol * panel.postTileSize;
         int worldY = worldRow * panel.postTileSize;
         int screenX = worldX - panel.player.worldX + panel.player.screenX;
         int screenY = worldY - panel.player.worldY + panel.player.screenY;

         if (worldX + panel.postTileSize > panel.player.worldX - panel.player.screenX &&
               worldX - panel.postTileSize < panel.player.worldX + panel.player.screenX &&
               worldY + panel.postTileSize > panel.player.worldY - panel.player.screenY &&
               worldY - panel.postTileSize < panel.player.worldY + panel.player.screenY) {
            g2D.drawImage(tile[currentTile].image, screenX, screenY, panel.postTileSize, panel.postTileSize, null);
         }

         worldCol++;
         if (worldCol == panel.maxWorldCol) {
            worldCol = 0;

            worldRow++;
         }
      }
   }
}