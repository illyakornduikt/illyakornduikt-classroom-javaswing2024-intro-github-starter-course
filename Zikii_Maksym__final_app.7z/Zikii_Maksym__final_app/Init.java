import app.main.start.Game;

public class Init {
   public static void main(String args[]) {
      new Game();
   }
}